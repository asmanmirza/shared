const firebaseConfig = {
  apiKey: "AIzaSyAG6kYJEfezEq8aMDnIKDsKnCqkIZQplTc",
  authDomain: "inno-bot-app.firebaseapp.com",
  projectId: "inno-bot-app",
  storageBucket: "inno-bot-app.appspot.com",
  messagingSenderId: "746485565476",
  appId: "1:746485565476:web:6851210cd169ad5e52f0b1",
};

export default firebaseConfig;

// const app = initializeApp(firebaseConfig);
