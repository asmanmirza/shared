import React from "react";
import SmallCard from "../../components/career/SmallCard";

function Career() {
  return (
    <div>
      <div className="row">
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
      </div>
    </div>
  );
}

export default Career;
