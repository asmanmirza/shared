import React from "react";
import Address from "./Address";
import Documentation from "./Documentation";
import JobLocation from "./JobLocation";
import Personal from "./Personal";
import Qulification from "./Qulification";
// import UserDetails from "./UserDetails";
// import AddressDetails from "./AddressDetails";
// import Confirmation from "./Confirmation";
import { v4 as uuidv4 } from "uuid";

function Index() {
  const [state, setState] = React.useState({
    step: 1,
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    city: "",
    state: "",
    zip: "",
  });

  const [jobId, setJobId] = React.useState(uuidv4());

  const nextStep = () => {
    const { step } = state;
    setState({
      step: step + 1,
    });
  };

  const prevStep = () => {
    const { step } = state;
    setState({
      step: step - 1,
    });
  };

  const handleChange = (event) => {
    setState((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };

  const { step } = state;
  // const inputValues = { firstName, lastName, email, address, city, state, zip };
  switch (step) {
    case 1:
      return (
        <Personal
          nextStep={nextStep}
          handleChange={handleChange}
          jobId={jobId}
          //   inputValues={inputValues}
        />
      );
    case 2:
      return (
        <Address
          nextStep={nextStep}
          prevStep={prevStep}
          jobId={jobId}
          //   handleChange={handleChange}
          //   inputValues={inputValues}
        />
      );
    case 3:
      return (
        <Qulification
          nextStep={nextStep}
          prevStep={prevStep}
          jobId={jobId}
          //   inputValues={inputValues}
        />
      );
    case 4:
      return (
        <JobLocation
          nextStep={nextStep}
          prevStep={prevStep}
          jobId={jobId}
          //   inputValues={inputValues}
        />
      );

    case 5:
      return (
        <Documentation
          nextStep={nextStep}
          prevStep={prevStep}
          jobId={jobId}
          //   inputValues={inputValues}
        />
      );
  }
}

export default Index;
