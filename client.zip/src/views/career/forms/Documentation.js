import React from "react";
import axios from "axios";
function Documentation({ prevStep, nextStep, jobId }) {
  const [file, setFile] = React.useState({
    photo: false,
    signature: false,
    identitty: false,
  });
  const [panding, setPanding] = React.useState({
    photo: false,
    signature: false,
    identitty: false,
  });

  const [select, setSelect] = React.useState(0);
  const back = (e) => {
    e.preventDefault();
    prevStep();
  };
  const saveAndContinue = (e) => {
    e.preventDefault();
    // nextStep();
  };

  const handleSelect = (e) => {
    setSelect(e.target.value);
    // data.jobId = jobId;
    // formData.append("file", file, file.name);
    // formData.append("campainId", );
  };

  const handleFile = (e) => {
    const formData = new FormData();
    let file = e.target.files[0];
    formData.append("file", file, file.name);
    formData.append("panding", "photo");

    axios
      .post("http://localhost:4000/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((res) => {
        console.log("file", res.data);
      })
      .catch((err) => {
        console.log("err", err);
      });
  };
  return (
    <div>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Documentation Details</h5>

          <div className="row">
            <div className="col-md-12 col-sm-12">
              <div class=" mb-3">
                <label for="formFile" class="form-label">
                  Signature
                </label>
                <input
                  class="form-control"
                  type="file"
                  id="formFile"
                  onChange={handleFile}
                />
                {/* <div class="spinner-border text-danger" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div> */}
              </div>
            </div>

            <div className="col-md-12 col-sm-12">
              <div class="mb-3">
                <label for="formFile" class="form-label">
                  Photograph
                </label>
                <input
                  class="form-control"
                  type="file"
                  id="formFile"
                  onChange={handleFile}
                />
              </div>
            </div>
            <div className="col-md-12 col-sm-12">
              <label for="exampleDataList" class="form-label">
                Datalist example
              </label>
              <select
                class="form-select"
                aria-label="Default select example"
                onChange={handleSelect}
              >
                <option value="0" selected>
                  Aadhar
                </option>
                <option value="1">Voter Id Card</option>
                <option value="2">PAN Card</option>
                <option value="3">Passport</option>
                <option value="4">Driving Licence</option>
              </select>
            </div>

            <div className="col-md-12 col-sm-12">
              <div class="mb-3">
                <label for="formFile" class="form-label">
                  Front
                </label>
                <input
                  class="form-control"
                  type="file"
                  id="formFile"
                  onChange={handleFile}
                />
              </div>
            </div>
            <div
              className="col-md-12 col-sm-12"
              style={{ display: select == 0 ? "block" : "none" }}
            >
              <div class="mb-3">
                <label for="formFile" class="form-label">
                  Back
                </label>
                <input
                  class="form-control"
                  type="file"
                  id="formFile"
                  onChange={handleFile}
                />
              </div>
            </div>

            <div className="col-md-12 col-sm-12">
              <button
                type="button"
                className="btn btn-dark"
                style={{ marginRight: 10 }}
                onClick={back}
              >
                Back <i className="fas fa-long-arrow-alt-right"></i>
              </button>
              <button
                type="button"
                className="btn btn-dark"
                onClick={saveAndContinue}
              >
                Finish <i className="fas fa-long-arrow-alt-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Documentation;
