import React from "react";
import axios from "axios";
import { config } from "../../../config";
import { toast } from "react-toastify";

function Qulification({ prevStep, nextStep, jobId }) {
  const [sec, setSec] = React.useState(false);
  const [srSec, setSrSec] = React.useState(false);
  const [ug, setUg] = React.useState(false);
  const [pg, setPg] = React.useState(false);
  const [data, setData] = React.useState({});

  const handleChange = (event) => {
    setData((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };

  const back = (e) => {
    e.preventDefault();
    prevStep();
  };
  const saveAndContinue = (e) => {
    console.log("qquli", data);
    data.jobId = jobId;
    e.preventDefault();
    nextStep();
  };
  return (
    <div>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Qulification Details</h5>

          <div className="row">
            <div className="col-md-12 col-sm-12">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  value=""
                  id="defaultCheck1"
                  onClick={() => {
                    setSec(!sec);
                    setSrSec(false);
                    setUg(false);
                    setPg(false);
                  }}
                  checked={sec}
                />
                <label class="form-check-label" for="defaultCheck1">
                  Secondary
                </label>
              </div>
            </div>

            <div className="col-md-12 col-sm-12">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  value=""
                  id="defaultCheck1"
                  onClick={() => {
                    setSec(!srSec);
                    setSrSec(!srSec);
                    setUg(false);
                    setPg(false);
                  }}
                  checked={srSec}
                />
                <label class="form-check-label" for="defaultCheck1">
                  Senior Secondary
                </label>
              </div>
            </div>

            <div className="col-md-12 col-sm-12">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  value=""
                  id="defaultCheck1"
                  onClick={() => {
                    setSec(!ug);
                    setSrSec(!ug);
                    setUg(!ug);
                    setPg(false);
                  }}
                  checked={ug}
                />
                <label class="form-check-label" for="defaultCheck1">
                  Graduate
                </label>
              </div>
              <div style={{ display: ug ? "block" : "none" }}>
                <div className="col-md-6 col-sm-12">
                  <div className="mb-3">
                    <label
                      for="exampleFormControlInput1"
                      className="form-label"
                    >
                      Degree
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="degree"
                      name="degree"
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-sm-12">
                  <div className="mb-3">
                    <label
                      for="exampleFormControlInput1"
                      className="form-label"
                    >
                      Discipline
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="discipline"
                      name="discipline"
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-12 col-sm-12">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="checkbox"
                  value=""
                  id="defaultCheck1"
                  onClick={() => {
                    setSec(!pg);
                    setSrSec(!pg);
                    setUg(!pg);
                    setPg(!pg);
                  }}
                  checked={pg}
                />
                <label class="form-check-label" for="defaultCheck1">
                  Post Graduate
                </label>
              </div>
              <div style={{ display: pg ? "block" : "none" }}>
                <div className="col-md-6 col-sm-12">
                  <div className="mb-3">
                    <label
                      for="exampleFormControlInput1"
                      className="form-label"
                    >
                      Degree
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="degree"
                      name="pdegree"
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-sm-12">
                  <div className="mb-3">
                    <label
                      for="exampleFormControlInput1"
                      className="form-label"
                    >
                      Discipline
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="discipline"
                      name="pdiscipline"
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>

              <button
                type="button"
                className="btn btn-dark"
                style={{ marginRight: 10 }}
                onClick={back}
              >
                Back <i className="fas fa-long-arrow-alt-right"></i>
              </button>
              <button
                type="button"
                className="btn btn-dark"
                onClick={saveAndContinue}
              >
                Next <i className="fas fa-long-arrow-alt-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Qulification;
