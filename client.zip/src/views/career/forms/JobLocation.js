import React from "react";

function JobLocation({ prevStep, nextStep, jobId }) {
  const [data, setData] = React.useState({});

  const handleChange = (event) => {
    setData((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };

  const back = (e) => {
    e.preventDefault();
    prevStep();
  };
  const saveAndContinue = (e) => {
    console.log("save", data);

    e.preventDefault();
    data.jobId = jobId;
    nextStep();
  };
  return (
    <div>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">JobLocation Details</h5>

          <div className="row">
            <div className="col-md-12 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  First Prefrance
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="First Prefrance"
                  name="p1"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-12 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Second Prefrance
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Second Prefrance"
                  name="p2"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-12 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Third Prefrance
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Third Prefrance"
                  name="p3"
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <button
            type="button"
            className="btn btn-dark"
            style={{ marginRight: 10 }}
            onClick={back}
          >
            Back <i className="fas fa-long-arrow-alt-right"></i>
          </button>
          <button
            type="button"
            className="btn btn-dark"
            onClick={saveAndContinue}
          >
            Next <i className="fas fa-long-arrow-alt-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

export default JobLocation;
