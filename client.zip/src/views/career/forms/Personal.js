import React from "react";
import axios from "axios";
import { config } from "../../../config";
import { toast } from "react-toastify";

function Personal({ nextStep }) {
  const [data, setData] = React.useState({
    email: "",
    fatherName: "",
    fname: "",
    gender: "",
    lname: "",
    motherName: "",
    phone: "",
  });
  const handleChange = (event) => {
    setData((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };
  const saveAndContinue = (e) => {
    e.preventDefault();

    axios
      .post(config.baseUrl + config.personal, data)
      .then((res) => {
        console.log("step 1 comp");
        toast.success("1st step completed");
        nextStep();
      })
      .catch((err) => {
        toast.error("Internal server error");
      });
  };

  return (
    <div>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Personal Details</h5>

          <div className="row">
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  First Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="First Name"
                  name="fname"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Last Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Last Name"
                  name="lname"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Father's Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Father's Name"
                  name="fatherName"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Mothers's Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Mothers's Name"
                  name="motherName"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-12 col-sm-12">
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="gender"
                  id="exampleRadios1"
                  value={0}
                  onChange={handleChange}
                />
                <label class="form-check-label" for="exampleRadios1">
                  Male
                </label>
              </div>
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="gender"
                  id="exampleRadios2"
                  value={1}
                  onChange={handleChange}
                />
                <label class="form-check-label" for="exampleRadios2">
                  Female
                </label>
              </div>
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="gender"
                  id="exampleRadios3"
                  value={2}
                  onChange={handleChange}
                />
                <label class="form-check-label" for="exampleRadios3">
                  Other
                </label>
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Email
                </label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Email"
                  name="email"
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="mb-3">
                <label for="exampleFormControlInput1" className="form-label">
                  Phone Number
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Phone Number"
                  name="phone"
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <button
            type="button"
            className="btn btn-dark"
            onClick={saveAndContinue}
          >
            Next <i className="fas fa-long-arrow-alt-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Personal;
