import React from "react";
import desc from "../../asstes/desc.jpg";
import { useHistory } from "react-router-dom";

function CourseDiscp() {
  const history = useHistory();
  return (
    <div className="container">
      <div
        class="card mb-3"
        style={{ border: "none", borderRadius: 0, marginTop: 10 }}
      >
        <div class="row g-0">
          <div class="col-md-4">
            <img src={desc} class="img-fluid" alt="desc" />
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">Data Entry Operator</h5>
              <br />
              <h5 class="card-subtitle mb-2 text-muted">Job Description</h5>
              <p class="card-text">
                We are currently looking for a data entry operate who can
                operator our databases for updation and maintenance of the data.
                Data entry operator should have the knowledge of MS Excel for
                creating spreadsheets. Ideal Data Entry Operator is the one who
                knows fast typing, having proper knowledge of entering the data
                in spreadsheets. Candidate having an experience in Data Entry
                field be our priority. You have to work with the team of Data
                Manager..
              </p>
              <h5 class="card-subtitle mb-2 text-muted">
                No. Of Vacancies : 9000
              </h5>
              <h5 class="card-subtitle mb-2 text-muted">
                Eligibility Criteria
              </h5>
              <ol type="i">
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
              </ol>

              <h5 class="card-subtitle mb-2 text-muted">
                Educational Qualification
              </h5>
              <ul itemType="roman">
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
                <li> Candidates should have the knowledge</li>
              </ul>

              <p class="card-text">
                <small class="text-muted">Last updated 3 mins ago</small>
              </p>

              <button
                type="button"
                class="btn btn-outline-success"
                onClick={() => history.push("/apply")}
              >
                Apply Now <i class="fas fa-long-arrow-alt-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CourseDiscp;
