import React from "react";
import Multistep from "react-multistep";
import Index from "./forms/Index";

function Apply() {
  return (
    <div className="container">
      <div
        style={{
          padding: 25,
        }}
      >
        <Index />
      </div>
    </div>
  );
}

export default Apply;
