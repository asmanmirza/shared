import React from "react";
import Footer from "../../components/footer/Footer";
import Banners from "./Banners";
import Content from "./Content";
import Header from "./Header";
import Partner from "./Partner";

function Home() {
  return (
    <div>
      {/* <Header /> */}
      <Banners />
      <Content />
      <Partner />
      {/* <Footer /> */}
    </div>
  );
}

export default Home;
