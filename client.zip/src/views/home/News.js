import React from "react";

function News() {
  return (
    <div class="card news-card">
      <div class="card">
        <div class="card-body">
          <h6 class="card-subtitle mb-2 text-muted">News</h6>
          <ul
            id="ticker01"
            style={{
              listStyle: "none",
              paddingLeft: 0,
            }}
          >
            <li>
              <span>08/11/2021&nbsp;10:44 AM IST</span>
              <a href="#"> 11,451 new Covid-19 cases and 266 deaths in India</a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;11:19 AM IST</span>
              <a href="#">
                IRCTC receives overwhelming response for Shri Ramayana Yatra'
                train service According to a statement issued by the IRCTC
              </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;10:22 AM IST</span>
              <a href="#">
                PM Modi greets BJP veteran LK Advani on 94th birthday
              </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;09:51 AM IST</span>
              <a href="#">
                Tamil Nadu rain: Schools to remain shut in Sivaganga
              </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;09:00 AM IST</span>
              <a href="#"> Magnitude 4.4 earthquake hits Manipur </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;08:21 AM IST</span>
              <a href="#">
                Delhi's air quality remains 'severe' with AQI of 432
              </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;07:57 AM IST</span>
              <a href="#">
                4 CRPF jawans killed, 3 injured in fratricide in Chhattisgarh
              </a>
            </li>
            <hr class="hr" />
            <li>
              <span>08/11/2021&nbsp;07:04 AM IST</span>
              <a href="#">
                Drugs case: NCB DDG Gyaneshwar Singh leaves for Mumbai
              </a>
            </li>
            <hr class="hr" />
          </ul>
        </div>
      </div>
    </div>
  );
}

export default News;
