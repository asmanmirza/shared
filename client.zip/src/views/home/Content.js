import React from "react";
import ContentCard from "./ContentCard";
import News from "./News";
import Notifications from "./Notifications";
import SmallCard from "../../components/career/SmallCard";

function Content() {
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-8 col-sm-6">
          <ContentCard />
        </div>
        <div className="col-md-4 col-sm-6">
          <Notifications />
          <News />
        </div>
      </div>
      <div style={{ height: 40, marginTop: 10 }}>
        <center>
          <h5 className="card-title">Digital Learning</h5>
        </center>
      </div>
      <div className="row">
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
        <div className="col-md-4 col-sm-12">
          <SmallCard />
        </div>
      </div>
      <div style={{ height: 40, marginTop: 10 }}>
        <center>
          <a href="#">
            Read more <i class="fas fa-long-arrow-alt-right"></i>
          </a>
        </center>
      </div>
    </div>
  );
}

export default Content;
