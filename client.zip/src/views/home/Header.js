import React from "react";
import Botton from "../../components/header/Botton";
import Nav from "../../components/header/Nav";
import Top from "../../components/header/Top";

function Header() {
  return (
    <div>
      <Top />
      <Botton />
      <Nav />
    </div>
  );
}

export default Header;
