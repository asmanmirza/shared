import React from "react";
import p1 from "../../asstes/banners/1.png";
import p2 from "../../asstes/banners/2.png";
import p3 from "../../asstes/banners/3.png";
import p4 from "../../asstes/banners/4.png";
import p5 from "../../asstes/banners/5.png";
import p6 from "../../asstes/banners/6.png";
import p7 from "../../asstes/banners/7.png";
import p8 from "../../asstes/banners/8.png";
import p9 from "../../asstes/banners/9.png";
import p10 from "../../asstes/banners/10.png";

function Partner() {
  return (
    <div
      style={{
        width: "100%",
        height: 250,
        marginTop: 15,
      }}
    >
      <div style={{ height: 40, marginTop: 10 }}>
        <center>
          {" "}
          <h5 className="card-title">Our Partners</h5>
        </center>
      </div>
      <marquee>
        <img
          src={p1}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p2}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p3}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p4}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p5}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p6}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p7}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p8}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p9}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
        <img
          src={p10}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
      </marquee>
    </div>
  );
}

export default Partner;
