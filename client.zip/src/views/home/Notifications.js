import React from "react";

function Notifications() {
  return (
    <div>
      <div class="card news-card">
        <div class="card-body">
          <h6 class="card-subtitle mb-2 text-muted">Notifications</h6>
          <ul
            id="ticker01"
            style={{
              listStyle: "none",
              paddingLeft: 0,
            }}
          >
            <li>
              <span className="news-time">08/11/2021&nbsp;10:44 AM IST</span>
              <p className="news-text text-truncate">
                11,451 new Covid-19 cases and 266 deaths in India
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;11:19 AM IST</span>
              <p className="news-text text-truncate">
                IRCTC receives overwhelming response for Shri Ramayana Yatra'
                train service According to a statement issued by the IRCTC
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;10:22 AM IST</span>
              <p className="news-text text-truncate">
                PM Modi greets BJP veteran LK Advani on 94th birthday
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;09:51 AM IST</span>
              <p className="news-text text-truncate">
                Tamil Nadu rain: Schools to remain shut in Sivaganga
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;09:00 AM IST</span>
              <p className="news-text text-truncate">
                {" "}
                Magnitude 4.4 earthquake hits Manipur{" "}
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;08:21 AM IST</span>
              <p className="news-text text-truncate">
                Delhi's air quality remains 'severe' with AQI of 432
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;07:57 AM IST</span>
              <p className="news-text text-truncate">
                4 CRPF jawans killed, 3 injured in fratricide in Chhattisgarh
              </p>
            </li>
            <hr class="hr" />
            <li>
              <span className="news-time">08/11/2021&nbsp;07:04 AM IST</span>
              <p className="news-text text-truncate">
                Drugs case: NCB DDG Gyaneshwar Singh leaves for Mumbai
              </p>
            </li>
            <hr class="hr" />
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Notifications;
