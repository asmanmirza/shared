import React from "react";

function ContentCard() {
  return (
    <div>
      <div className="card-body">
        <h5 className="card-title">Employability</h5>
        <p className="card-text">
          SEED Program’s primary mission is to accelerate the economic
          development in emerging economies and drive high-value job creation
          through entrepreneurship, innovation and skills development. SEED
          Program’s Employability empowers students to learn the on-demand
          skills by providing trainings and pre-placement job offers.
        </p>
        <a href="#">
          Read more <i class="fas fa-long-arrow-alt-right"></i>
        </a>
      </div>

      <div className="card-body">
        <h5 className="card-title">Entrepreneurship</h5>
        <p className="card-text">
          In our Entrepreneurship Support Program, we support new entrepreneurs
          to start their businesses. In this way we are changing job seekers to
          job creators where more people will get jobs and unemployability will
          be vanished in upcoming time. Our Entrepreneurship Support Program
          will help new startups to grow and expand their business. We guide new
          entrepreneurs for fund raising and other important tasks that are
          required for the success of a business. The aim of our program is to
          spread the Entrepreneurship.
        </p>
        <a href="#">
          Read more <i class="fas fa-long-arrow-alt-right"></i>
        </a>
      </div>
      <div className="card-body">
        <h5 className="card-title">Scholarship</h5>
        <p className="card-text">
          Our Scholarship Program is mainly for students who are good in their
          studies and want to pursue higher studies. We support students by
          providing them scholarships for higher studies. We provide
          scholarships based on their performance level in education.
        </p>
        <a href="#">
          Read more <i class="fas fa-long-arrow-alt-right"></i>
        </a>
      </div>
    </div>
  );
}

export default ContentCard;
