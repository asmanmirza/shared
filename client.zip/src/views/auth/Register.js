import React from "react";
import login from "../../asstes/logo/seed.png";
import { useHistory } from "react-router-dom";
import axios from "axios";
import { config } from "../../config";
import { toast } from "react-toastify";

function Register() {
  const history = useHistory();
  const [data, setData] = React.useState({
    name: "",
    email: "",
    password: "",
    cpassword: "",
  });

  const handleRegister = () => {
    if (data.name === "") {
      toast.error("Please enter name!");
      return;
    }
    if (data.email === "") {
      toast.error("Please enter email!");
      return;
    }
    if (data.password === "") {
      toast.error("Please enter password!");
      return;
    }
    if (data.password !== data.cpassword) {
      toast.error("password and confirm password should match!");
      return;
    }

    axios
      .post(config.baseUrl + config.register, data)
      .then((res) => {
        console.log("register");
        toast.success("User registered successfully");
        history.push("/login");
      })
      .catch((er) => {
        console.log("reg err", er);
        toast.error("User registeration failed!");
      });
    // console.log("Login", data);
  };
  const handleChange = (event) => {
    setData((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };
  return (
    <div
      className="d-flex justify-content-center"
      style={{
        alignItems: "center",
        height: "100vh",
      }}
    >
      <div class="card">
        <center>
          <img
            src={login}
            alt="login"
            style={{
              width: 60,
              marginTop: 10,
            }}
          />
        </center>
        <div class="card-body">
          {/* <h5 class="card-title">Login</h5> */}
          <div class="input-group flex-nowrap">
            <span class="input-group-text" id="addon-wrapping">
              <i class="far fa-user"></i>
            </span>
            <input
              type="text"
              class="form-control"
              placeholder="Name"
              aria-label="Name"
              aria-describedby="addon-wrapping"
              name="name"
              onChange={handleChange}
            />
          </div>
          <br />
          <div class="input-group flex-nowrap">
            <span class="input-group-text" id="addon-wrapping">
              <i class="fas fa-user"></i>
            </span>
            <input
              type="text"
              class="form-control"
              placeholder="Email"
              aria-label="Username"
              aria-describedby="addon-wrapping"
              name="email"
              onChange={handleChange}
            />
          </div>
          <br />
          <div class="input-group flex-nowrap">
            <span class="input-group-text" id="addon-wrapping">
              <i class="fas fa-key"></i>
            </span>
            <input
              type="password"
              class="form-control"
              placeholder="Password"
              aria-label="Password"
              aria-describedby="addon-wrapping"
              name="password"
              onChange={handleChange}
            />
          </div>
          <br />
          <div class="input-group flex-nowrap">
            <span class="input-group-text" id="addon-wrapping">
              <i class="fas fa-key"></i>
            </span>
            <input
              type="password"
              class="form-control"
              placeholder="Confirm Password"
              aria-label="cPassword"
              aria-describedby="addon-wrapping"
              name="cpassword"
              onChange={handleChange}
            />
          </div>
          <br />
          <button
            type="button"
            class="btn btn-dark form-control"
            onClick={handleRegister}
          >
            Register <i class="fas fa-long-arrow-alt-right"></i>
          </button>
          <button
            type="button"
            class="btn btn-link form-control"
            onClick={() => history.push("/login")}
          >
            Have an Account? Login hare
          </button>
        </div>
      </div>
    </div>
  );
}

export default Register;
