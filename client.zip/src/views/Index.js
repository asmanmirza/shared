import React from "react";
import Footer from "../components/footer/Footer";
import Login from "./auth/Login";
import Register from "./auth/Register";
import Apply from "./career/Apply";
import Career from "./career/Career";
import CourseDiscp from "./career/CourseDiscp";
import Header from "./home/Header";
// import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Home from "./home/Home";

function Index() {
  return (
    <div>
      {/* <Header /> */}
      {/* <Home /> */}
      {/* <Career /> */}
      {/* <CourseDiscp /> */}
      <Apply />
      {/* <Footer /> */}
      {/* <Login /> */}
      {/* <Register /> */}
    </div>
  );
}

export default Index;
