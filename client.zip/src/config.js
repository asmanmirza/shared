export const config = {
  baseUrl: "http://localhost:4000",
  register: "/reg",
  personal: "/api/personal",
  address: "/api/address",
};
