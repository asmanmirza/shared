import React from "react";
import "./App.css";
import "react-toastify/dist/ReactToastify.css";
import Index from "./views/Index";
import { app } from "./auth/auth";
import { getAuth } from "firebase/auth";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
import Home from "./views/home/Home";
import Header from "./views/home/Header";
import Footer from "./components/footer/Footer";
import Career from "./views/career/Career";
import Login from "./views/auth/Login";
import Register from "./views/auth/Register";
import CourseDiscp from "./views/career/CourseDiscp";
import Apply from "./views/career/Apply";
import { ToastContainer } from "react-toastify";

function App() {
  const auth = getAuth(app);
  const [user, setUser] = React.useState(null);
  const [authCheck, setAuthCheck] = React.useState(true);

  async function onAuthStateChanged(user) {
    console.log("user--", user);
    setUser(user);
    // const token = await  auth?.currentUser?.getIdToken();
    // axios.defaults.headers.common["Authorization"] = token;
    // if (authCheck) setAuthCheck(false);
  }
  React.useEffect(() => {
    const subscriber = auth.onAuthStateChanged(onAuthStateChanged);
    return subscriber; // unsubscribe on unmount
  }, []);

  // if (auth?.currentUser) {
  //   return <></>;
  // }
  return (
    <div>
      <ToastContainer
        position="top-center"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      <Router>
        <Header />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/creers" component={Career} />
          <Route path="/login" component={Login} />
          <Route path="/reg" component={Register} />
          <Route path="/creers/descp" component={CourseDiscp} />
          <Route
            path="/apply"
            render={() =>
              auth?.currentUser ? <Apply /> : <Redirect to="/login" />
            }
          />
        </Switch>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
