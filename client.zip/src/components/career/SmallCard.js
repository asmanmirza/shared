import React from "react";
import { useHistory } from "react-router-dom";

function SmallCard() {
  const history = useHistory();
  return (
    <div>
      <div class="card" style={{ border: "none" }}>
        <div class="card-body">
          <center>
            <i class="fas fa-laptop-code" style={{ fontSize: 80 }}></i>
          </center>
          <figure class="text-center">
            <blockquote class="blockquote">
              <p>Learn Computer Basic and Advaced</p>
            </blockquote>
            <figcaption class="blockquote-footer">
              INR <cite title="Source Title">9999/-</cite>
            </figcaption>
            {/* <figcaption class="">
              Apply Now <i class="fas fa-long-arrow-alt-right"></i>
            </figcaption> */}
            <button
              type="button"
              class="btn btn-outline-info"
              onClick={() => history.push("/creers/descp")}
            >
              Learn More <i class="fas fa-long-arrow-alt-right"></i>
            </button>
          </figure>
        </div>
      </div>
    </div>
  );
}

export default SmallCard;
