import React from "react";
import logo from "../../asstes/logo/logo.png";
import swach from "../../asstes/logo/swach.png";

//SEED_LOGO_FB.png";

function Botton() {
  return (
    <div className="bottom-container">
      <div className="bottom-left">
        <img
          src={logo}
          alt="logo"
          style={{
            width: 182,
            // height: 110,
            marginLeft: 35,
          }}
        />
      </div>
      <div className="bottom-right">
        <img
          src={swach}
          alt="swach"
          style={{
            width: 182,
            // height: 110,
            marginRight: 35,
          }}
        />
      </div>
    </div>
  );
}

export default Botton;
