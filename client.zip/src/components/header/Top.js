import React from "react";

function Top() {
  return (
    <div className="top-container">
      <div className="top-left">
        भारत सरकार <div className="text-right">GOVERNMENT OF INDIA</div>
      </div>
      <div className="top-right"></div>
    </div>
  );
}

export default Top;
