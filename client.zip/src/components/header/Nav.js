import React from "react";
import { Link } from "react-router-dom";
import { getAuth } from "firebase/auth";
import { app } from "../../auth/auth";

function Nav() {
  const auth = getAuth(app);
  return (
    <nav
      className="navbar navbar-expand-lg navbar-light"
      style={{ paddingLeft: 30, paddingRight: 30, backgroundColor: "#3eb347" }}
    >
      <div className="container-fluid">
        <Link className="navbar-brand" href="#" style={{ color: "white" }}>
          Seed Online
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarText"
          aria-controls="navbarText"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarText">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link to="/" className="nav-link active" aria-current="page">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/creers" className="nav-link" href="#">
                Creers
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/program" className="nav-link" href="#">
                Program
              </Link>
            </li>
          </ul>

          {auth && auth.currentUser ? (
            <Link onClick={() => auth.signOut()} className="nav-link" href="#">
              Logout
            </Link>
          ) : (
            <Link to="/login" className="nav-link" href="#">
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Nav;
