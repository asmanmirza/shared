import React from "react";

function Footer() {
  return (
    <div
      style={{
        width: "100%",
        height: 250,
        marginTop: 15,
        backgroundColor: "#504c5c",
        paddingTop: 10,
      }}
    >
      <div className="container">
        <div className="row">
          <div className="col-md-3 col-sm-12">
            <div
              class="card"
              style={{
                backgroundColor: "transparent",
                color: "white",
                border: "none",
              }}
            >
              <div class="card-body">
                <h5 class="card-title">Contact us</h5>
                This is some text within a card body.
              </div>
            </div>
          </div>
          <div className="col-md-3 col-sm-12"></div>
          <div className="col-md-3 col-sm-12"></div>
          <div className="col-md-3 col-sm-12"></div>
        </div>
      </div>
    </div>
  );
}

export default Footer;
