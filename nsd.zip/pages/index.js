import Head from "next/head";
import Link from "next/link";

export default function Home({ msg }) {
  return (
    <div>
      <Head>
        <title>Welcome To NoWhere!</title>
      </Head>

      <div style={{ padding: "5px 20px" }}>
        <center>
          {/* <h3>{msg}!</h3> */}
          <li>
            <Link href="/home">
              <a>Home</a>
            </Link>
          </li>
          <li>
            <Link href="/about">
              <a>About</a>
            </Link>
          </li>
          <span>Oh! Yes I know I am vulnerable</span>
          <em> - d4rky</em>
        </center>
      </div>
    </div>
  );
}

export async function getServerSideProps(context) {
  return {
    props: { msg: "d4rky" },
  };
}

export const config = { amp: true };
