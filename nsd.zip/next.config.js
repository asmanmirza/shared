module.exports = {
  reactStrictMode: true,
  // experimental: {
  //   amp: {
  //     optimizer: {},
  //     // skipValidation: true,
  //   },
  // },
};
