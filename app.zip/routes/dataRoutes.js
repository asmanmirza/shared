const exprss = require("express");
const {
  personal,
  address,
  qulification,
  perfrance,
  document,
} = require("../apis/datas/apply");
const { userSubscription } = require("../apis/users/subscription");

const router = exprss.Router();

router.post("/personal", personal);
router.post("/address", address);
router.post("/qulification", qulification);
router.post("/prefrance", perfrance);
router.post("/document", document);
router.post("/subscription", userSubscription);

module.exports = router;
