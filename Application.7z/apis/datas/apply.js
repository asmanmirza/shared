const JobApply = require("../../models/JobApply");

const personal = async (req, res) => {
  try {
    const {
      jobId = 1,
      email,
      fatherName,
      fname,
      gender,
      lname,
      motherName,
      phone,
      step = 1,
    } = req.body;

    const newJobApply = new JobApply({
      jobId,
      email,
      fatherName,
      fname,
      gender,
      lname,
      motherName,
      phone,
      step,
    });

    await newJobApply.save();
    return res.status(200).json({
      msg: "step 1 completed",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

const address = async (req, res) => {
  try {
    const { jobId = 1, address, district, hn, pin, state, street } = req.body;

    const job = await JobApply.findOne({ jobId });
    console.log("--", job);
    if (!job)
      return res.status(201).json({
        msg: "first you complete step 1",
      });

    job.address = address;

    job.district = district;
    job.hn = hn;
    job.pin = pin;
    job.state = state;
    job.street = street;
    job.step = 2;
    await job.save();
    return res.status(200).json({
      msg: "step 2 completed",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

const qulification = async (req, res) => {
  try {
    const { jobId, qulification, degree, discipline, pdegree, pdiscipline } =
      req.body;

    const job = JobApply.findOne({ jobId });
    if (!job)
      return res.status(201).json({
        msg: "first you complete step 1 and 2",
      });

    job.qulification = qulification;
    job.degree = degree;
    job.discipline = discipline;
    job.pdegree = pdegree;
    job.pdiscipline = pdiscipline;
    job.step = 3;
    await job.save();
    return res.status(200).json({
      msg: "step 2 completed",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

const perfrance = async (req, res) => {
  try {
    const { jobId, prefrenceA, prefrenceB, prefrenceC } = req.body;

    const job = JobApply.findOne({ jobId });
    if (!job)
      return res.status(201).json({
        msg: "first you complete step 1 and 2",
      });

    job.prefrenceA = prefrenceA;
    job.prefrenceB = prefrenceB;
    job.prefrenceC = prefrenceC;
    job.step = 4;
    await job.save();
    return res.status(200).json({
      msg: "step 2 completed",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

const document = async (req, res) => {
  try {
    const { jobId, signature, photo, idBack, idFront, idName } = req.body;

    const job = JobApply.findOne({ jobId });
    if (!job)
      return res.status(201).json({
        msg: "first you complete step 1 and 2",
      });

    job.signature = signature;
    job.photo = photo;
    job.idBack = idBack;
    job.idFront = idFront;
    job.idName = idName;
    job.step = 5;

    await job.save();
    return res.status(200).json({
      msg: "step 2 completed",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

module.exports = { perfrance, personal, qulification, address, document };
