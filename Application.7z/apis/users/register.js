const { getAuth } = require("firebase-admin/auth");

const register = async (req, res) => {
  try {
    const { name, email, password, role = "student" } = req.body;

    // console.log( "i al call", req.body);
    const { uid } = await getAuth(global.firebaseApp).createUser({
      email: email,
      emailVerified: false,
      password: password,
      displayName: name,

      photoURL: "http://www.example.com/12345678/photo.png",
      disabled: false,
    });

    console.log(uid);

    getAuth(global.firebaseApp)
      .setCustomUserClaims(uid, { role: role })
      .then(() => {
        console.log("user created");
        // The new custom claims will propagate to the user's ID token the
        // next time a new one is issued.
        res.status(200).json({ msg: "success" });
      })
      .catch((err) => {
        console.log("error", err);
        res.status(500).json({ msg: "fail" });
      });
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "fail" });
  }
};

module.exports = { register };
