const firebaseConfig = {
  type: "service_account",
  project_id: "inno-bot-app",
  private_key_id: "c9f0f14d55b93219c21dfb286885333a651ea562",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDIoNs2KXfh2shM\nVslP+4Px/RnvYES9e+A00A9k1Pk/l3pcQxgR2BV9TfP9ni4WmnrEK+4vzsynAkaP\nVN/gxyJ3HTPS39pGF9YaoqmAhOXqjFqAejFDEGEovha+jQvzZx4r1lQZjCNFfrjQ\nY7RNeDwpLElm+/bLlVt9QXNuTkmptEFWGQncdKLAvnR5x14EKGoqGSKXt7jVdejv\nvn3Y+llXH6akmld4Ny4yUkdOr4y6HgGUZnUQ76HHC4wjYPeSOgHWHzPC8YV6FSUx\nFmf52ww0QyNq9AV3bgpZ/5knTL4GciwvnmwfYyGUCppt8MBNnEP0A7V7Fc424MPn\n4sJsBpE1AgMBAAECggEAA5FkxJ5RLPmUlVL3yo3ZB10ucGTgZBRHZPkMRQlKk3hw\nqyJgU7TpkOxpeemtvSYrJ8D2P/BoEFJIifUC9D7mXILu8IGdoqB65Mdex1PVuOmd\nFGrX5G7uo2haBDKC82WykioCHeAxomNCCyayxqvsOfk5JvU1KuKxmVUoJd6LjdKI\nQGzlVJUwC7YhgDdEo2Q0sw7mKBbBWcgTUVHSs4UP+KFn3EN6QoN3DNA2BdGFSUu+\nPrMx3UAM9xl2VH+NHDPLTDSQlXMvpnJXV5dho0yiTRAn3mpyHPdw6SG96tQld0Bl\n5UwfNHKWkbWmM0czaK3ejhlG7DlIwQpa+PK0q5U+wwKBgQDy2qX1nFVTvzQ5MZcD\nOAYrlmxCd6uImNGhJNItXjjrj5ak7R8dt2fC6UiTXnemgiEtLmrvPwiRneEZ6JYX\nkzuCIHsXTtj5rAQjjCY+9DRxKpT3bjx7J5oDf5LceA/J5foyIcj4M+W2ISQSvAJr\nzQzhtZ2SamijOHh3bphLCqLnAwKBgQDTfRCCvP0D6JIzvN9yQ8Q3DQJhnEctX5T+\nO8qYAnC1yByAot64mhpOHur89wSWovMn/KynqGhje/020tCr/lswvwGeJwzF32uo\nX0Kyl4wdr2oYiFgYxeCS3OrN6VIx3tLg+KJGN8DZGQQzzi1wGCqDhweS3awvNKLx\nJK/q9jg1ZwKBgQCrIdSs/RtLxoMggodt5z7B3GAxfm7L9RRTv8Sz35+wryBy2/1/\nTUy7FvTjlEAwf6atVfZY3UxGgMCtJy8NMd1PV2AmDpPrbIIGIq6Y0jFaRa1vpqjM\nCB4JtQ5ieeB2X68tQI2ECd4nt7bZ1M7H9FjNfNOq530Q96w8TRzYVIhyzQKBgQDG\nJEFIy/mdJNN9Z7JNYtI95ZFalElXaFq2SpyICJlCpqaVmoJin/aPRIZS1LfWzfpU\nd3Xnam/K7UqSh7b7vUYAiKPiYaGk7ar2x7E8k6Gx2jvjmjI3m4TI8/OFUdkxYhte\nrXOTp/6lJ7v5MWz+vZVvPx5Iaik83OrgVMgAsgh9dwKBgQDANM/qAgzxTH2YIirq\nIAX74uDMYhf/9Axr/YLWht0oHQzpEsOzB+Hvc0T6mseU1VaDOWnW2PH0L9plOSDW\nI+Ds/95qKuey/TGcRTqPcfUEZTdO5x5pRRK6J1b8IvdEHy4VrVW6noRSghJ08ya3\nJXhM3CM1IPclapP8MvPp02SxRg==\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-qwxug@inno-bot-app.iam.gserviceaccount.com",
  client_id: "112557090276051960795",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-qwxug%40inno-bot-app.iam.gserviceaccount.com",
};

module.exports = firebaseConfig;

// firebase-adminsdk-qwxug@inno-bot-app.iam.gserviceaccount.com
