const exprss = require("express");
const { personal, address } = require("../apis/datas/apply");

const router = exprss.Router();

router.post("/personal", personal);
router.post("/address", address);

module.exports = router;
