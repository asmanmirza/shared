// ;

const UserSubscription = require("../../models/UserSubscription");

const userSubscription = async (req, res) => {
  try {
    const {
      jobId,
      uid,

      amount,
      paymentID,
      orderId,
    } = req.body;

    const newUserSubscription = new UserSubscription({
      uid,
      subscriptions: [
        {
          jobId,
          amount,
          paymentID,
          orderId,
        },
      ],
    });

    await newUserSubscription.save();
    return res.status(200).json({
      msg: "payment details saved",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

module.exports = { userSubscription };
