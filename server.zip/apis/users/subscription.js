// ;

const UserSubscription = require("../../models/UserSubscription");

const userSubscription = async (req, res) => {
  try {
    const { id, uid, type, email, amount, paymentID, orderId } = req.body;
    // console.log("---------sub-----", req.body);

    const newUserSubscription = new UserSubscription({
      uid,
      email,
      type,
      subscriptions: {
        id,
        amount,
        paymentID,
        orderId,
      },
    });

    await newUserSubscription.save();
    return res.status(200).json({
      msg: "payment details saved",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      msg: "Internal server error",
    });
  }
};

module.exports = { userSubscription };
