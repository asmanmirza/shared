require("dotenv").config();
const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ extended: true, limit: "100mb" }));

// const { initializeApp } = require("firebase-admin/app");
const firebaseConfig = require("./config.js");

const admin = require("firebase-admin");

global.firebaseApp = admin.initializeApp({
  credential: admin.credential.cert(firebaseConfig),
});

require("./db");

const { register } = require("./apis/users/register.js");
app.get("/reg", (req, res) => {
  res.send("hii").end();
});
app.post("/api/reg", register);

app.listen(4000, () => {
  console.log("server lesten on 4000");
});

//
// global.rootDir = __dirname;

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, __dirname + "/uploads");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });
app.post("/upload", upload.single("file"), (req, res) => {
  console.log(req.body, "file", req.file);
  res.send({ ...req.file, ...req.body }).end();
});

app.use("/api", require("./routes/dataRoutes"));

const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: process.env.R_KEY,
  key_secret: process.env.R_SECRATE,
});

const JOB = require("./models/Job");
const DigitalLearning = require("./models/DigitalLearning.js");

app.post("/pay", async (req, res) => {
  try {
    let job =
      req.body.type == "job"
        ? await JOB.findOne({ _id: req.body.id })
        : await DigitalLearning.findOne({ _id: req.body.id });
    console.log("jobid", job, req.body);

    const payment_capture = 1;
    const amount = req.body.type == "job" ? job.application_fee : job.price;
    const currency = "INR";

    const options = {
      amount: 100, //amount * 100,
      currency,
      receipt: "hftryukijhgutyujh78iou98766543567",
      payment_capture,
    };

    try {
      const response = await razorpay.orders.create(options);
      console.log(response);
      res.json({
        id: response.id,
        currency: response.currency,
        amount: response.amount,
      });
    } catch (error) {
      console.log(error);
    }
  } catch (er) {
    console.log(er);
  }
});

app.use(express.static(path.join(__dirname, "/client/build")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "/client/build", "index.html"));
});

module.exports = app;
