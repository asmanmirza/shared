const firebaseConfig = {
  type: "service_account",
  project_id: "udyamit-db8e4",
  private_key_id: "0d432660e3b2286ab34e8171b5f8d8a03e729f53",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDrzRBNzdUstivo\nCB5Iotpljy7GScyUwuPlOExiXhtjSiWqdrToteW+UkmdZ8A4Ax1UmspMP4ep0hG5\nPbi44iLg0K98HrJFY/erd9UTjZTyIrWz3r1KgXDB/3HfhGuxheyqPppHtzjJp1n5\nsjTMVldvaE37cGqdYulOGclfC00ERI5aDmSj/nVSQ4qZQpwpkcnLc+KA7TXZkl4H\nvFWu9TjGyI1/kFAI5WyPPvWZvkgWPuzowvJ9bwwo9oNx6HUMH67F74BY7/2r8qU6\nJQ1PuVaMAOWja7vkNxY4U7Wsdsa5SaYl3x0VOJQbEYnfEQvvHtdN5qsnzvQ3BfrT\nV/M0dG3jAgMBAAECggEAFOnMkuH5EKydi0hBC1cqQIyo7Nw5wU3hsYBDQgwvqKg4\nW/yIQgVz+WPJ9KRxh2Y7UTgjTgzqZtTjTocbXYZs6nyHu93rGL1rh3Eq3D+X4LvU\nWr4cEsIVMpeJzXWsqYODwHup6kdlSXlGwR8dkKvtuEtLc0v+oLPXll4yHnRdoc2Z\nLkSG1IuQqUgzay/S0XNujctslOZIWG7K5yLSknbGIgLWFmkuP3D12OS+xZHcwOcv\nVpgdWsJGSdrfH4XWqFvqcnYXR4i31nvEJRg8YorSme3/6XvQOqRo7g0Yy0hVoA4Y\nLxNWADYVpVaq984GyrRmGBPQlZ6GxPm0phRvdrZA+QKBgQD5cr4YkGArxK0Iq6I3\nk8QYx6MG39mGu5t62Mhb3UUxBI+e962AwhOuBmFefvLIIttBxaOiK8KS9KmMPBn2\nPehzBU3kquCBnqFPJ7tXoIbfnofH6f2uRJF8cqA4YuV/t3TZylu3QUDXAjBN8uf4\nbv9rAqHP+YiuCBKQ9B4klBMXWwKBgQDx/o8qDNzA1ApxIXn8uDvuUBPJZzXZw2JF\ngzgq04tQ8hOUNbCdnN7Er2CLfEc5cr4OYDZI0LXJVbjk3vSbSuuZG2b57SyaR1b9\ndqj6d6CyqS4S4/cr+KExdUcErk9qRLkQC0m9+l6V27ZYPk0IdSAomdiA1FVzrgQZ\ns3zFyhRSGQKBgQDaHYu8/NkqzEGk+DbStAFezYlupGOXXQoZw96F/RfYQa23iciL\ncqg0nd2b/BMcDuZ7P27SicMMLqTmO1NULlPH51Zx4TyH+oYAKbS1bWcht4PwuViZ\nfdlc4PnZ9BfKskaZfUjvFz60AnTsY76US7JJBrconH/39JUPbHXC9DsxSwKBgAso\nn9VijnNd07Vvw75BiJHuo1rwJW2LMubdrCNdadkrsHdvGlvKNgN/ysXjzyz4+4aS\nLS6iYR+Nkl8LYOAgTkjbGJ6Br0LV807wv8384i4a2wMH/AfNCTHMpJ+0ofjWfmoc\n+yOFfgMPBJOBG/A95mO45GDcaaxR4+KDgkdkkBdRAoGBANwkz6X0ZwSNPrqaLDGG\nJCXk011U3wbdzkiXJXi53G7rlES5iN1Iew/csld1vNzXat/4tcxu6My88Ub8VGf+\noiM5UCB2I3ABEVQkbGXnXe27Y94jV8lkn8rHRgQZTbXqf1ZBDiYjNTg4Kb5Wok9v\n5jil4QgwqLj3gcB7pr4czcqD\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-528dc@udyamit-db8e4.iam.gserviceaccount.com",
  client_id: "100639691414371075204",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-528dc%40udyamit-db8e4.iam.gserviceaccount.com",
};

module.exports = firebaseConfig;
