const firebaseConfig = {
  type: "service_account",
  project_id: "yottaseedonline",
  private_key_id: "62e3ed3a92c571ca645fb6a6fe779a972df3bbd5",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCiy8tRnE44SEhD\nwco5XaSaqzo5guLyH2l/LMbnjDK5NepPPZdQo4riNZxyXadKeQxZsC00iVEzGDkw\nCXSEichyt7E0hQ3zxjiEVXDV9CAHogylGglqBQ1y5VSzmZK4EaXISKD6txsXBcoV\nV/DwRUa6qUwYgMkfl5bly1M5lCaacNpsmEi51rJ5e9rYD/7BH1NMWfECSYPxk6SW\nJxCIU0VnIX+PVLLERVcBlQ0tzQa/zO9wPkkWL3u/8Mo9Rwuj4/8XX7zbbEVHASgB\ndD6Pnz7qF42ammyy+n40SuyprWtZeD9onCKX6KhFUiFsIk5Q4ONqwsrX7blnhxYO\n3j0XZwL/AgMBAAECggEAI66Qe2xLlrl9IWDN7sHwLLiAFA/0p0YsTOQnGqRXj9HZ\n8BFbY6Dc9ZTzm/ucCc47X0MmvV+lrRHPoxBHei9rAH3zuMO7GaXmSFcj2rld9d5W\ncC+jRZoi5v6OEKmGB5NSp3IH2rwck3DA6Om0FS3SAWLPG4XKz4Jd4DMvJC0tQudE\n1WG/qDqg2qVUChZ+KRRiMiM3iHlWMDb8Ttn10d1B8FYtCTKAysueHDrFOKYjCGD4\nbYQLJG6vTnuAe+0qQlDU176UlvjPaszY4uJY6hq68rp5c4s19iij9YOJPK8vZRaF\n4dNx0ojRfXv7SVyHICGh6JW2L5CheFJVuomBSM2TFQKBgQDWyI6i8Y68Dnkgp1he\nCJWvujfkRKv/lfRlxyoBrtC+hQvedVmgBLimGrAEK9KSV3jxBQo/1x5u/wOaj2Iq\nd095N3q2F6m+HAv4dlTH2wc3mAvt3BIaGTEJx5kQxElceFbu2ITf0gsTFat6vzbR\nB+98DYm9G/+fnVpYDhhoFgwSdQKBgQDCCU7gFiOa08yQVmaWixm0a78glzY6d9k6\nVpSKHd0ZsBVop0nWI+MudWh66GFGGz/HTiwVtovkAFSmmtcJqBCxYowHGjS0bJBN\ndkRwPK2J2PLAJxk41TYsjkelYCFgdBSeBMpgFMKAkecQFbS5N221ohxNakGl95+l\nlKTvtKTpIwKBgQCL8X8mYfebRl7bzM2B71wAdHfoTmo3DLCCBCO1lv7BtBSIrLNp\n1MmuyKK5BQide0r810jXUcWtkpD5isTuYHCyzVgx/vcFPGb8S7VvxqFMMtBK+eH9\niT5vXdK4nvwhuPMDiqYA42190Ne7EY2Y4u/CR1vgkLacfD0aNIzofLz+5QKBgQC+\nMX+F+U13IupeBMLUB47vobmbiXyXPQjJvTomU/V4i3fAuFGQvGagEGeUKhnHLUiL\n5N0jf2aJ26UeFaJ4jaunJDCbeZ11yQB9XVLiLSfxeZ0gqnJ3mc5bSC+EM8EjmUTo\nS0vPeCna+qjhxFT8RA+evUM+wsuMkjeDhztQ1uHavwKBgQDLjQAtE1XMOvt7/MK6\nHC7SchWcuiEZIQL/YpnDwSxJPCM53hjVE9JbYd+3GHfOwwSXAH+A60DCBhoZfQRj\nSFRa7kJT6vMQLv8AgKt4Er54iCS/U414CtOohPrTmyCshG/sw8QelwTCNc1+oeYQ\nE7havlerA9B016Oq8dvdFWXMuw==\n-----END PRIVATE KEY-----\n",
  client_email:
    "firebase-adminsdk-cdayz@yottaseedonline.iam.gserviceaccount.com",
  client_id: "105662604664102981102",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-cdayz%40yottaseedonline.iam.gserviceaccount.com",
};

module.exports = firebaseConfig;

// firebase-adminsdk-qwxug@inno-bot-app.iam.gserviceaccount.com
