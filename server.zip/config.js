// const firebaseConfig = {
//   type: "service_account",
//   project_id: "inno-bot-app",
//   private_key_id: "c9f0f14d55b93219c21dfb286885333a651ea562",
//   private_key:
//     "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDIoNs2KXfh2shM\nVslP+4Px/RnvYES9e+A00A9k1Pk/l3pcQxgR2BV9TfP9ni4WmnrEK+4vzsynAkaP\nVN/gxyJ3HTPS39pGF9YaoqmAhOXqjFqAejFDEGEovha+jQvzZx4r1lQZjCNFfrjQ\nY7RNeDwpLElm+/bLlVt9QXNuTkmptEFWGQncdKLAvnR5x14EKGoqGSKXt7jVdejv\nvn3Y+llXH6akmld4Ny4yUkdOr4y6HgGUZnUQ76HHC4wjYPeSOgHWHzPC8YV6FSUx\nFmf52ww0QyNq9AV3bgpZ/5knTL4GciwvnmwfYyGUCppt8MBNnEP0A7V7Fc424MPn\n4sJsBpE1AgMBAAECggEAA5FkxJ5RLPmUlVL3yo3ZB10ucGTgZBRHZPkMRQlKk3hw\nqyJgU7TpkOxpeemtvSYrJ8D2P/BoEFJIifUC9D7mXILu8IGdoqB65Mdex1PVuOmd\nFGrX5G7uo2haBDKC82WykioCHeAxomNCCyayxqvsOfk5JvU1KuKxmVUoJd6LjdKI\nQGzlVJUwC7YhgDdEo2Q0sw7mKBbBWcgTUVHSs4UP+KFn3EN6QoN3DNA2BdGFSUu+\nPrMx3UAM9xl2VH+NHDPLTDSQlXMvpnJXV5dho0yiTRAn3mpyHPdw6SG96tQld0Bl\n5UwfNHKWkbWmM0czaK3ejhlG7DlIwQpa+PK0q5U+wwKBgQDy2qX1nFVTvzQ5MZcD\nOAYrlmxCd6uImNGhJNItXjjrj5ak7R8dt2fC6UiTXnemgiEtLmrvPwiRneEZ6JYX\nkzuCIHsXTtj5rAQjjCY+9DRxKpT3bjx7J5oDf5LceA/J5foyIcj4M+W2ISQSvAJr\nzQzhtZ2SamijOHh3bphLCqLnAwKBgQDTfRCCvP0D6JIzvN9yQ8Q3DQJhnEctX5T+\nO8qYAnC1yByAot64mhpOHur89wSWovMn/KynqGhje/020tCr/lswvwGeJwzF32uo\nX0Kyl4wdr2oYiFgYxeCS3OrN6VIx3tLg+KJGN8DZGQQzzi1wGCqDhweS3awvNKLx\nJK/q9jg1ZwKBgQCrIdSs/RtLxoMggodt5z7B3GAxfm7L9RRTv8Sz35+wryBy2/1/\nTUy7FvTjlEAwf6atVfZY3UxGgMCtJy8NMd1PV2AmDpPrbIIGIq6Y0jFaRa1vpqjM\nCB4JtQ5ieeB2X68tQI2ECd4nt7bZ1M7H9FjNfNOq530Q96w8TRzYVIhyzQKBgQDG\nJEFIy/mdJNN9Z7JNYtI95ZFalElXaFq2SpyICJlCpqaVmoJin/aPRIZS1LfWzfpU\nd3Xnam/K7UqSh7b7vUYAiKPiYaGk7ar2x7E8k6Gx2jvjmjI3m4TI8/OFUdkxYhte\nrXOTp/6lJ7v5MWz+vZVvPx5Iaik83OrgVMgAsgh9dwKBgQDANM/qAgzxTH2YIirq\nIAX74uDMYhf/9Axr/YLWht0oHQzpEsOzB+Hvc0T6mseU1VaDOWnW2PH0L9plOSDW\nI+Ds/95qKuey/TGcRTqPcfUEZTdO5x5pRRK6J1b8IvdEHy4VrVW6noRSghJ08ya3\nJXhM3CM1IPclapP8MvPp02SxRg==\n-----END PRIVATE KEY-----\n",
//   client_email: "firebase-adminsdk-qwxug@inno-bot-app.iam.gserviceaccount.com",
//   client_id: "112557090276051960795",
//   auth_uri: "https://accounts.google.com/o/oauth2/auth",
//   token_uri: "https://oauth2.googleapis.com/token",
//   auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
//   client_x509_cert_url:
//     "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-qwxug%40inno-bot-app.iam.gserviceaccount.com",
// };
const firebaseConfig = {
  type: "service_account",
  project_id: "yottaseedonline",
  private_key_id: "62e3ed3a92c571ca645fb6a6fe779a972df3bbd5",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCiy8tRnE44SEhD\nwco5XaSaqzo5guLyH2l/LMbnjDK5NepPPZdQo4riNZxyXadKeQxZsC00iVEzGDkw\nCXSEichyt7E0hQ3zxjiEVXDV9CAHogylGglqBQ1y5VSzmZK4EaXISKD6txsXBcoV\nV/DwRUa6qUwYgMkfl5bly1M5lCaacNpsmEi51rJ5e9rYD/7BH1NMWfECSYPxk6SW\nJxCIU0VnIX+PVLLERVcBlQ0tzQa/zO9wPkkWL3u/8Mo9Rwuj4/8XX7zbbEVHASgB\ndD6Pnz7qF42ammyy+n40SuyprWtZeD9onCKX6KhFUiFsIk5Q4ONqwsrX7blnhxYO\n3j0XZwL/AgMBAAECggEAI66Qe2xLlrl9IWDN7sHwLLiAFA/0p0YsTOQnGqRXj9HZ\n8BFbY6Dc9ZTzm/ucCc47X0MmvV+lrRHPoxBHei9rAH3zuMO7GaXmSFcj2rld9d5W\ncC+jRZoi5v6OEKmGB5NSp3IH2rwck3DA6Om0FS3SAWLPG4XKz4Jd4DMvJC0tQudE\n1WG/qDqg2qVUChZ+KRRiMiM3iHlWMDb8Ttn10d1B8FYtCTKAysueHDrFOKYjCGD4\nbYQLJG6vTnuAe+0qQlDU176UlvjPaszY4uJY6hq68rp5c4s19iij9YOJPK8vZRaF\n4dNx0ojRfXv7SVyHICGh6JW2L5CheFJVuomBSM2TFQKBgQDWyI6i8Y68Dnkgp1he\nCJWvujfkRKv/lfRlxyoBrtC+hQvedVmgBLimGrAEK9KSV3jxBQo/1x5u/wOaj2Iq\nd095N3q2F6m+HAv4dlTH2wc3mAvt3BIaGTEJx5kQxElceFbu2ITf0gsTFat6vzbR\nB+98DYm9G/+fnVpYDhhoFgwSdQKBgQDCCU7gFiOa08yQVmaWixm0a78glzY6d9k6\nVpSKHd0ZsBVop0nWI+MudWh66GFGGz/HTiwVtovkAFSmmtcJqBCxYowHGjS0bJBN\ndkRwPK2J2PLAJxk41TYsjkelYCFgdBSeBMpgFMKAkecQFbS5N221ohxNakGl95+l\nlKTvtKTpIwKBgQCL8X8mYfebRl7bzM2B71wAdHfoTmo3DLCCBCO1lv7BtBSIrLNp\n1MmuyKK5BQide0r810jXUcWtkpD5isTuYHCyzVgx/vcFPGb8S7VvxqFMMtBK+eH9\niT5vXdK4nvwhuPMDiqYA42190Ne7EY2Y4u/CR1vgkLacfD0aNIzofLz+5QKBgQC+\nMX+F+U13IupeBMLUB47vobmbiXyXPQjJvTomU/V4i3fAuFGQvGagEGeUKhnHLUiL\n5N0jf2aJ26UeFaJ4jaunJDCbeZ11yQB9XVLiLSfxeZ0gqnJ3mc5bSC+EM8EjmUTo\nS0vPeCna+qjhxFT8RA+evUM+wsuMkjeDhztQ1uHavwKBgQDLjQAtE1XMOvt7/MK6\nHC7SchWcuiEZIQL/YpnDwSxJPCM53hjVE9JbYd+3GHfOwwSXAH+A60DCBhoZfQRj\nSFRa7kJT6vMQLv8AgKt4Er54iCS/U414CtOohPrTmyCshG/sw8QelwTCNc1+oeYQ\nE7havlerA9B016Oq8dvdFWXMuw==\n-----END PRIVATE KEY-----\n",
  client_email:
    "firebase-adminsdk-cdayz@yottaseedonline.iam.gserviceaccount.com",
  client_id: "105662604664102981102",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-cdayz%40yottaseedonline.iam.gserviceaccount.com",
};

module.exports = firebaseConfig;

// firebase-adminsdk-qwxug@inno-bot-app.iam.gserviceaccount.com
