const mongoose = require("mongoose");

const jobApplySchema = mongoose.Schema({
  jobId: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
  },
  fatherName: String,
  fname: String,
  gender: String,
  lname: String,
  motherName: String,
  phone: String,

  address: String,
  district: String,
  hn: String,
  pin: String,
  state: String,
  street: String,

  qulification: String,
  degree: String,
  discipline: String,
  pdegree: String,
  pdiscipline: String,

  prefrenceA: String,
  prefrenceB: String,
  prefrenceC: String,

  signature: String,
  photo: String,
  idBack: String,
  idFront: String,
  idName: String,
  step: Number,
});

module.exports = mongoose.model("JobApply", jobApplySchema);
